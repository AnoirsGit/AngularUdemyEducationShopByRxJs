import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Recipe } from './recipe.model'
import { DataStorageService } from '../shared/data-storage.service';
import { RecipeDataService } from './recipe-data.service';

@Injectable({providedIn: 'root'})
export class RecipesResolverService implements Resolve<Recipe[]>{
 constructor(private dataStorage: DataStorageService ,
  private recipeService: RecipeDataService){

 }

 resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
  const recipes = this.recipeService.getRecipe();

  if ( recipes.length ===0){
    return this.dataStorage.fetchRecipes();
  }
  else{
    return recipes;
  }
  
 }

} 