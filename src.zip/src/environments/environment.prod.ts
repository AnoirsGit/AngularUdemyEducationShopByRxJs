export const environment = {
  production: true,
  firebasePIKey: 'AIzaSyDOjhwggJRXDXGPuD5cDfgLYxqxDHaiYpg'
};
